const s = () => {
    let x = 5;

    const f = () => {
        let y = 10;
        return x + y;
    };
    return f;
}

const f = s();
console.log(f()); // 15
