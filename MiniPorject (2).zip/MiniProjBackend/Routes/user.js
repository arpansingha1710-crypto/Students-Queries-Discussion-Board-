const express = require('express');
const router = express.Router();
const pool = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const {JWT_KEY} = require("../System");
const { isLoggedIn } = require('../Authorization');

const saltRounds = 10;

router.post('/register', async (req, res) => {
    const {name, email, password} = req.body;
    
    try {
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        const newUser = await pool.query(
            'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING *',
            [name, email, hashedPassword]
        );
        res.status(201).json(newUser.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({error: 'Server error'});
    }
})

router.post('/login', async (req, res) => {
    const {email, password} = req.body;
    try {
        const user = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (user.rows.length === 0) {
            return res.status(400).json({error: 'Invalid credentials'});
        }
        const isMatch = await bcrypt.compare(password, user.rows[0].password);
        if (!isMatch) {
            return res.status(400).json({error: 'Invalid credentials'});
        }
        const token = jwt.sign({id: user.rows[0].id}, JWT_KEY);
        res.json({user: {token, id: user.rows[0].id, name: user.rows[0].name, email: user.rows[0].email}});
    } catch (err) {
        console.error(err.message);
        res.status(500).json({error: 'Server error'});
    }
})

router.post('/verify', isLoggedIn, async (req, res) => {
    try {
        const user = await pool.query('SELECT * FROM users WHERE id = $1', [req.userId]);
        if (user.rows.length === 0) {
            return res.status(404).json({error: 'User not found'});
        }
        res.json({name: user.rows[0].name, email: user.rows[0].email, id: user.rows[0].id, token: req.token});
    } catch (err) {
        console.error(err.message);
        res.status(500).json({error: 'Server error'});
    }
});

module.exports = router;