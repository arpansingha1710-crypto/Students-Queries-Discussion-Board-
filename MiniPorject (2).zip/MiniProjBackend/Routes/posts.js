const express = require('express');
const { isLoggedIn } = require('../Authorization');
const pool = require('../db');
const router = express.Router();

router.post("/create", isLoggedIn, async (req, res) => {
    try {
        const { title, description, tags } = req.body;
        const userId = req.userId;

        if (!title || !description) {
            return res.status(400).json({ message: "Title and content are required" });
        }

        const newPost = await pool.query(
            "INSERT INTO posts (author_id, title, content, tags) VALUES ($1, $2, $3, $4) RETURNING *",
            [userId, title, description, tags]
        );

        res.json(newPost.rows[0]);

    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

router.post("/get", isLoggedIn, async (req, res) => {
    try {
        const id = req.body.postId;
        const post = await pool.query(
            "SELECT posts.*, users.name as by FROM posts JOIN users ON posts.author_id = users.id WHERE posts.id = $1",
            [id]
        );
        if (post.rows.length === 0) {
            return res.status(404).json({ message: "Post not found" });
        }

        const comments = await pool.query(
            "SELECT comments.*, users.name as by FROM comments JOIN users ON comments.author_id = users.id WHERE comments.post_id = $1",
            [id]
        );
        const postData = post.rows[0];
        postData.comments = comments.rows;
        res.json(postData);

    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

router.post("/getRecentPosts", isLoggedIn, async (req, res) => {
    try {
        const posts = await pool.query(
            "SELECT posts.*, users.name as by FROM posts JOIN users ON posts.author_id = users.id ORDER BY posts.created_at DESC LIMIT 10"
        );
        res.json({ posts: posts.rows });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

router.post("/getAllPosts", isLoggedIn, async (req, res) => {
    const userId = req.body.id;

    try {
        const posts = await pool.query(
            "SELECT posts.*, users.name FROM posts JOIN users ON posts.author_id = users.id WHERE posts.author_id = $1 ORDER BY posts.created_at DESC",
            [userId]
        );
        res.json({ posts: posts.rows });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
})

module.exports = router;