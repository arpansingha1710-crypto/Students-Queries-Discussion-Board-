const JWT_KEY = 'miniproj';

module.exports = {
    JWT_KEY
}
