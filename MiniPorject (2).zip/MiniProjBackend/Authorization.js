const jwt = require('jsonwebtoken');
const {JWT_KEY} = require("./System");


const isLoggedIn = (req, res, next) => {
    const auth = req.get("Authorization");
    const token = auth ? auth.split(" ")[1] : null;
    if (!token) {        
        return res.status(401).json({error: 'No token provided'});
    }
    
    
    jwt.verify(token, JWT_KEY, (err, decoded) => {
        if (err) {            
            return res.status(403).json({error: 'Failed to authenticate token'});
        }
        req.userId = decoded.id;
        req.token = token;
        next();
    });
}

module.exports = {
    isLoggedIn
}