const Pool = require('pg').Pool

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    password: 'piyus',
    port: 5432,
    database: 'miniproj'
})

module.exports = pool;